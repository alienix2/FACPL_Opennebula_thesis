package com.policyManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PolicyManagerApplication {

    public static void main(String[] args) {
        SpringApplication.run(PolicyManagerApplication.class, args);
    }
}